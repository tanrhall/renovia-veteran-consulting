export default function App() {
  return (
    <div>
      <h1>Renovia Veteran Consulting</h1>
      <p>Your full site code goes here. Paste the React component from ChatGPT canvas into this file.</p>
    </div>
  )
}
